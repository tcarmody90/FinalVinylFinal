<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>Edit Inventory Table</title>

      <style type="text/css">
         body {
            background-color: #83c985;
            font-family: Verdana, sans-serif;
            width: 100%;
            margin: auto;
            color: #ffffff;
         }
         table, tr, td {
            border-width: 3px;
            border-style: solid;
            border-color: #3e8e41;
            margin:auto;
         }
         .center {
            display: block;
            position: relative;
            width:80%;
            margin:auto;
         }
         .ERR {
            color: red;
            font-weight: bold;
         }
      </style>

   </head>

   <body>

   <h2>Edit Inventory Table</h2>

      <div class="center">

      <?php

         // ======================================================================
         // Initialize MySQLi server connection parameters
         // ======================================================================

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "Vinyls";
         $tableName = "Inventory";

         // ======================================================================
         // Create connection with server
         // ======================================================================

         $conn = new mysqli($servername, $username, $password, $dbName);

         // ======================================================================
         // Check connection
         // ======================================================================

         if (!$conn)
         {
            die("Connection to Database $dbName failed: " . mysqli_connect_error() . "<br />");
         }
         else
         {
            echo "Connected to Database $dbName successfully<br />";
         }

         // ======================================================================
         // Display record to be edited
         // ======================================================================

         $sku_edit = $_POST['sku'];

         echo "<p>searching for record ". $sku_edit . " in table " . $tableName . "</p>";

         echo "<p> query: 'SELECT * FROM " . $tableName . " WHERE sku=" . $sku_edit . "' </p>";

         $sql = "SELECT * FROM $tableName WHERE sku=$sku_edit";
         $result = mysqli_query($conn, $sql);

         echo "<p> number of rows retrieved: " . mysqli_num_rows($result) . "</p>";
         $row = mysqli_fetch_array($result);
         echo "<form action='Modify_Table_Inventory.php' method='post'>";
            echo "Genre: &nbsp;&nbsp;";
            echo "<select name='genre' id='genre' >";
            if($row['genre'] == 'Jazz') {
               echo "<option value='Jazz' selected>Jazz</option>";
            } else {
               echo "<option value='Jazz'>Jazz</option>";
            }
            if($row['genre'] == 'Pop') {
               echo "<option value='Pop' selected>Pop</option>";
            } else {
               echo "<option value='Pop'>Pop</option>";
            }
            if($row['genre'] == 'EDM') {
               echo "<option value='EDM' selected>EDM</option>";
            } else {
               echo "<option value='EDM'>EDM</option>";
            }
            if($row['genre'] == 'Country') {
               echo "<option value='Country' selected>Country</option>";
            } else {
               echo "<option value='Country'>Country</option>";
            }
            if($row['genre'] == 'Rock') {
               echo "<option value='Rock' selected>Rock</option>";
            } else {
               echo "<option value='Rock'>Rock</option>";
            }
            echo "</select>";
            echo "&nbsp;&nbsp;Artist: &nbsp;&nbsp;";
            echo "<input type='text' name='artist' id='artist' value='". $row['artist'] . "' />";
            echo "&nbsp;&nbsp;Title: &nbsp;&nbsp;";
            echo "<input type='text' name='title' id='title' value='". $row['title'] . "' />";
            echo "&nbsp;&nbsp;Year: &nbsp;&nbsp;";
            echo "<input type='text' name='year' id='year' value='". $row['year'] . "' />";
            echo "&nbsp;&nbsp;Price: &nbsp;&nbsp;$";
            echo "<input type='text' name='price' id='price' value='". $row['price'] . "' />";
            echo "<br /><br />Album Cover (big): &nbsp;&nbsp;";
            echo "<input type='text' name='album_cover_big' id='album_cover_big' value='". $row['album_cover_big'] . "' />";
            echo "&nbsp;&nbsp;Album Cover (small): &nbsp;&nbsp;";
            echo "<input type='text' name='album_cover_small' id='album_cover_small' value='". $row['album_cover_small'] . "' />";
            echo "&nbsp;&nbsp;Number in stock: &nbsp;&nbsp;";
            echo "<input type='text' name='numberInStock' id='numberInStock' value='". $row['numberInStock'] . "' />";
            echo "<br /><br />";
            echo "<input type='hidden' name='sku' value='$sku_edit' />";
            echo "<input type='submit' value='Edit Inventory Table' />";
         echo "</form>";


/*
$row['genre'] = "Rock";
$row['artist'] = "Jimi Hendrix";
$row['title'] = "Purple Haze";
$row['year'] = 1970;
$row['price'] = 1000.00;
$row['album_cover_big'] = "./images/jimihendrix_cover_big.jpg";
$row['album_cover_small'] = "./images/jimihendrix_cover_small.jpg";
$row['numberInStock'] = 7;

         if (mysqli_num_rows($result) > 0)
         {
      ���   // output data of each row
        ��� $row = mysqli_fetch_array($result);
               // output data for selected row
               echo "<form action='Modify_Table_Inventory.php' method='post'>";
               echo "Genre: &nbsp;&nbsp;";
               echo "<select name='genre' id='genre' >;
               if($row['genre'] == 'Jazz') {
                  echo "<option value="Jazz" selected>Jazz</option>";
               } else {
                  echo "<option value="Jazz">Jazz</option>";
               }
               if($row['genre'] == 'Pop') {
                  echo "<option value="Pop" selected>Pop</option>";
               } else {
                  echo "<option value="Pop">Pop</option>";
               }
               if($row['genre'] == 'EDM') {
                  echo "<option value="EDM" selected>EDM</option>";
               } else {
                  echo "<option value="EDM">EDM</option>";
               }
               if($row['genre'] == 'Country') {
                  echo "<option value="Country" selected>Country</option>";
               } else {
                  echo "<option value="Country">Country</option>";
               }
               if($row['genre'] == 'Rock') {
                  echo "<option value="Rock" selected>Rock</option>";
               } else {
                  echo "<option value="Rock">Rock</option>";
               }
               echo "</select>";
               echo "&nbsp;&nbsp;Artist: &nbsp;&nbsp;";
               echo "<input type='text' name='artist' id='artist' value='". $row['artist'] . "' />";
               echo "&nbsp;&nbsp;Title: &nbsp;&nbsp;";
               echo "<input type='text' name='title' id='title' value='". $row['title'] . "' />";
               echo "&nbsp;&nbsp;Price: &nbsp;&nbsp;$";
               echo "<input type='text' name='price' id='price' value='". $row['price'] . "' />";
               echo "<br /><br />Album Cover (big): &nbsp;&nbsp;";
               echo "<input type='text' name='album_cover_big' id='album_cover_big' value='". $row['album_cover_big'] . "' />";
               echo "&nbsp;&nbsp;Album Cover (small): &nbsp;&nbsp;";
               echo "<input type='text' name='album_cover_small' id='album_cover_small' value='". $row['album_cover_small'] . "' />";
               echo "&nbsp;&nbsp;Number in stock: &nbsp;&nbsp;";
               echo "<input type='text' name='numberInStock' id='numberInStock' value='". $row['numberInStock'] . "' />";
               echo "<br /><br />";
               echo "<input type='hidden' name='sku' value='$sku_edit' />";
               echo "<input type='submit' value='Edit Inventory Table' />";
               echo "</form>";
         }
         else
         {
            echo "0 results<br />";
         }
*/

         // ======================================================================
         // Close connection with server
         // ======================================================================

         mysqli_close($conn);

      ?>

      <h4> Return to Main Menu <a href="DB_Menu.htm" ><button>DB Menu</button></a> </h4>

      </div>

   </body>

</html>
