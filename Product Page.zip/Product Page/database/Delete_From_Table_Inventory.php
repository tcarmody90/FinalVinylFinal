<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>Delete From Inventory Table</title>

      <style type="text/css">
         body {
            background-color: #83c985;
            font-family: Verdana, sans-serif;
            width: 100%;
            margin: auto;
            color: #ffffff;
         }
         table, tr, td {
            border-width: 3px;
            border-style: solid;
            border-color: #3e8e41;
            margin:auto;
         }
         .center {
            display: block;
            position: relative;
            width:80%;
            margin:auto;
         }
         .ERR {
            color: red;
            font-weight: bold;
         }
      </style>

   <?php
      function display_inventory($conn, $tableName)
      {
         // ======================================================================
         // Display All Records
         // ======================================================================

         $sql = "SELECT * FROM $tableName";
         $result = mysqli_query($conn, $sql);

         if (mysqli_num_rows($result) > 0)
         {
            // output header row
            echo "<table border='1'>";
            echo "<tr>";
            echo "<th>SKU #</th>";
            echo "<th>Genre</th>";
            echo "<th>Artist</th>";
            echo "<th>Title</th>";
            echo "<th>Year</th>";
            echo "<th>Price</th>";
            echo "<th>Album Cover (big)</th>";
            echo "<th>Album Cover (small)</th>";
            echo "<th># In Stock</th>";
            echo "</tr>";

            // output data of each row
            while($row = mysqli_fetch_array($result))
            {
               echo "<tr>";
               echo "<td>" . $row["sku"] . "</td>";
               echo "<td>" . $row["genre"] . "</td>";
               echo "<td>" . $row["artist"] . "</td>";
               echo "<td>" . $row["title"] . "</td>";
               echo "<td>" . $row["year"] . "</td>";
               echo "<td>$" . $row["price"] . "</td>";
               echo "<td>" . $row["album_cover_big"] . "</td>";
               echo "<td>" . $row["album_cover_small"] . "</td>";
               echo "<td>" . $row["numberInStock"] . "</td>";
               echo "</tr>";
            }
            echo "</table>";
         }
         else
         {
            echo "0 results<br />";
         }
      }

      function delete_from_table($conn, $tableName, $sku_del)
      {
         // ======================================================================
         // Delete A Record
         // ======================================================================

         // sql to delete a record
         $sql = "DELETE FROM $tableName WHERE sku=$sku_del";

         if (mysqli_query($conn, $sql)) {
            echo "Record deleted successfully<br /><br />";
         } else {
            echo "Error deleting record: " . mysqli_error($conn);
         }

      }

   ?>

   </head>

   <body>

   <h2>Delete From Inventory Table</h2>

      <div class="center">

      <?php

         // ======================================================================
         // Initialize MySQLi server connection parameters
         // ======================================================================

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "Vinyls";
         $tableName = "Inventory";

         // ======================================================================
         // Create connection with server
         // ======================================================================

         $conn = new mysqli($servername, $username, $password, $dbName);

         // ======================================================================
         // Check connection
         // ======================================================================

         if (!$conn)
         {
            die("Connection to Database $dbName failed: " . mysqli_connect_error() . "<br />");
         }
         else
         {
            echo "Connected to Database $dbName successfully<br /><br />";
         }

         // ======================================================================
         // Delete Record
         // ======================================================================

         $sku_del = $_POST['sku'];
         delete_from_table($conn, $tableName, $sku_del);

         // ======================================================================
         // Display All Records
         // ======================================================================

         display_inventory($conn, $tableName);

         // ======================================================================
         // Close connection with server
         // ======================================================================

         mysqli_close($conn);

      ?>

      <form action="Display_Table_Inventory.php">
         <h4>
            Display Inventory&nbsp;
            <button>Display Inventory Table</button>
         </h4>
      </form>

      <h4> Add A Record <a href="Add_To_Table_Inventory.htm" ><button>Add Record To Inventory Table</button></a> </h4>

      <form action="Delete_From_Table_Inventory.php" method="post">
         <h4>
            Delete A Record (SKU#): &nbsp;&nbsp;
            <input type="text" name="sku" id="sku" />
            &nbsp;&nbsp;
            <input type="submit" value="Delete Record From Inventory Table" />
         </h4>
      </form>

      <form action="Edit_Table_Inventory.php" method="post">
         <h4>
            Edit A Record (SKU#): &nbsp;&nbsp;
            <input type="text" name="sku" id="sku" />
            &nbsp;&nbsp;
            <input type="submit" value="Edit Record From Inventory Table" />
         </h4>
      </form>

      <h4> Do A Search <a href="Search_Table_Inventory.htm"><button>Search Inventory Table</button></a> </h4>

      <h4> Return to Main Menu <a href="DB_Menu.htm" ><button>DB Menu</button></a> </h4>

      </div>

   </body>

</html>
