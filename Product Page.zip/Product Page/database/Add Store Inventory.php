<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Add Store Inventory</title>
</head>

<body>

    <?php
        // ======================================================================
        // Initialize MySQLi server connection parameters
        // ======================================================================

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbName = "Vinyls";
        $tableName = "Inventory";

        // ======================================================================
        // Create connection with server
        // ======================================================================

        $conn = new mysqli($servername, $username, $password, $dbName);

        // ======================================================================
        // Check connection
        // ======================================================================

        if (!$conn)
        {
            die("Connection to Database $dbName failed: " . mysqli_connect_error() . "<br />");
        }
        else
        {
            echo "Connected to Database $dbName successfully<br />";
        }

        // ======================================================================
        // Insert Records
        // ======================================================================

        function addRecord($aGenre, $aArtist, $aTitle, $aYear, $aPrice, $aBigImg, $aSmImg, $aStock)
        {
            $genre = $aGenre;
            $artist = $aArtist;
            $title = $aTitle;
            $year = $aYear;
            $price = $aPrice;
            $album_cover_big = $aBigImg;
            $album_cover_small = $aSmImg;
            $numberInStock = $aStock;
    
            global $tableName;
            global $conn;
            $sql = "SELECT * FROM $tableName";
            $sql = "INSERT INTO $tableName (genre, artist, title, year, price, album_cover_big, album_cover_small, numberInStock)
            VALUES ('$genre', '$artist', '$title', '$year', '$price', '$album_cover_big', '$album_cover_small', '$numberInStock')";

            if (mysqli_query($conn, $sql))
            {
                echo "<br />New record created successfully<br /><br />";
            }
            else
            {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn) . "<br />";
            }
        }

        // ROCK
        addRecord("Rock", "ACDC", "Back in Black", "1980", "23.99", "images/albums/acdc_big.jpg", "images/albums/acdc_small.jpg", "12");
        addRecord("Rock", "Boston", "Boston", "1988", "24.95", "images/albums/boston.jpg", "images/albums/boston.jpg", "154");
        addRecord("Rock", "Doors", "Doors", "1975", "44.52", "images/albums/doors.jpg", "images/albums/doors.jpg", "3");
        addRecord("Rock", "Eagles", "Hotel California", "1973", "442.00", "images/albums/eagles.jpg", "images/albums/eagles.jpg", "8");
        addRecord("Rock", "Fleetwood Mac", "Fleetwood Mac", "1425", "45.33", "images/albums/fleetwoodmac.jpg", "images/albums/fleetwoodmac.jpg", "94");
        addRecord("Rock", "Journey", "Greatest Hits", "1988", "29.99", "images/albums/journey.jpg", "images/albums/journey.jpg", "11");
        addRecord("Rock", "Led Zeppelin", "Led Zeppelin IV", "1971", "19.99", "images/albums/ledzeppelin.jpg", "images/albums/ledzeppelin.jpg", "10");
        addRecord("Rock", "Pink Floyd", "The Wall", "1985", "19.99", "images/albums/pinkfloyd.jpg", "images/albums/pinkfloyd.jpg", "2");
        addRecord("Rock", "Queen", "Greatest Hits I", "1981", "39.99", "images/albums/queen.jpg", "images/albums/queen.jpg", "9");
        addRecord("Rock", "Van Halen", "1984", "1984", "14.99", "images/albums/vanhalen.jpg", "images/albums/vanhalen.jpg", "7");

        // EDM
        addRecord("EDM", "Aural Vampire", "Zoltank", "2010", "19.99", "images/albums/auralvampire.png", "images/albums/auralvampire.png", "24");
        addRecord("EDM", "Cybotron", "Enter", "1983", "14.99", "images/albums/cybotron.png", "images/albums/cybotron.png", "19");
        addRecord("EDM", "Daft Punk", "Discovery", "2001", "29.99", "images/albums/daftpunk.png", "images/albums/daftpunk.png", "16");
        addRecord("EDM", "Darude", "Before the Storm", "2000", "24.99", "images/albums/darude.png", "images/albums/darude.png", "21");
        addRecord("EDM", "deadmau5", "4x4=12", "2010", "19.99", "images/albums/deadmau5.png", "images/albums/deadmau5.png", "25");
        addRecord("EDM", "Donna Summer", "I Remember Yesterday", "1977", "19.99", "images/albums/donna.png", "images/albums/donna.png", "17");
        addRecord("EDM", "Enigma", "MCMXC a.D.", "1990", "19.99", "images/albums/enigma.png", "images/albums/enigma.png", "20");
        addRecord("EDM", "Gouryella", "Tenshi", "2000", "9.99", "images/albums/gouryella.png", "images/albums/gouryella.png", "23");
        addRecord("EDM", "Herbie Hancock", "Future Shock", "1983", "19.99", "images/albums/herbie.png", "images/albums/herbie.png", "18");
        addRecord("EDM", "Italians Do It Better", "After Dark", "2007", "19.99", "images/albums/italians.png", "images/albums/italians.png", "22");

        // POP
        addRecord("Pop", "Michael Jackson", "Thriller", "1982", "19.99", "images/albums/jacksonBIG.jpg", "images/albums/jacksonSMALL", "34");
        addRecord("Pop", "Madonna", "Like a Virgin", "1984", "19.99", "images/albums/madonnaBIG.jpg", "images/albums/madonnaSMALL", "35");
        addRecord("Pop", "Britney Spears", "...Baby One More Time", "1999", "19.99", "images/albums/britneyBIG.jpg", "images/albums/britneySMALL.jpg", "36");
        addRecord("Pop", "The Beatles", "Sgt. Pepper\'s Lonely Hearts Club Band", "1967", "19.99", "images/albums/beatlesBIG.jpg", "images/albums/beatlesSMALL.jpg", "37");
        addRecord("Pop", "Elvis Presley", "Elvis Presley", "1956", "19.99", "images/albums/elvisBIG.jpg", "images/albums/elvisSMALL.jpg", "38");
        addRecord("Pop", "Elton John", "Goodbye Yellow Brick Road", "1973", "25.00", "images/albums/eltonBig.jpg", "images/albums/eltonSmall.jpg", "39");
        addRecord("Pop", "Mariah Carey", "Music Box", "1993", "89.99", "images/albums/mariahBig.jpg", "images/albums/mariahSmall.jpg", "40");
        addRecord("Pop", "Stevie Wonder", "Songs in the Key of Life", "1976", "34.99", "images/albums/wonderBig.jpg", "images/albums/stevieSmall.jpg", "41");
        addRecord("Pop", "Janet Jackson", "Janet", "1993", "14.99", "images/albums/janetBig.jpg", "images/albums/janetSmall.jpg", "42");
        addRecord("Pop", "Whitney Houston", "Whitney Houston", "1985", "9.99", "images/albums/whoustonBig.jpg", "images/albums/whoustonSmall.jpg", "43");

        // COUNTRY
        addRecord("Country", "Melre Haggard", "Mama Tried", "1968", "24.99", "images/albums/merleBig.jpg", "images/albums/merleSmall.jpg", "50");
        addRecord("Country", "Johnny Cash", "I Walk the Line", "1964", "34.99", "images/albums/cashBig.jpg", "images/albums/cashSmall.jpg", "51");
        addRecord("Country", "Willie Nelson", "Stardust", "1978", "24.99", "images/albums/willieBig.jpg", "images/albums/willieSmall.jpg", "52");
        addRecord("Country", "George Jones", "I Am What I Am", "1980", "19.99", "images/albums/jonesBig.jpg", "images/albums/jonesSmall.jpg", "53");
        addRecord("Country", "Garth Brooks", "No Fences", "1990", "14.99", "images/albums/garthBig.jpg", "images/albums/garthSmall.jpg", "54");
        addRecord("Country", "George Strait", "Blue Clear Sky", "1996", "14.99", "images/albums/straitBig.jpg", "images/albums/straitSmall.jpg", "55");
        addRecord("Country", "Tim McGraw", "Not a Moment Too Soon", "1994", "19.99", "images/albums/mcgrawBig.jpg", "images/albums/mcgrawSmall.jpg", "56");
        addRecord("Country", "Shania Twain", "Come On Over", "1997", "24.99", "images/albums/twainBig.jpg", "images/albums/twainSmall.jpg", "57");
        addRecord("Country", "Carrie Underwood", "Some Hearts", "2005", "19.99", "images/albums/underwoodBig.jpg", "images/albums/underwoodSmall.jpg", "58");
        addRecord("Country", "Waylon Jennings", "Ol\' Waylon", "1977", "9.99", "images/albums/waylonBig.jpg", "images/albums/waylonSmall.jpg", "59");

        // JAZZ
        addRecord("Jazz", "Miles Davis", "Kind of Blue", "1959", "19.99", "images/albums/davis-BIG.jpg", "images/albums/davis-BIG.jpg", "61");
        addRecord("Jazz", "Getz", "Gilberto", "1963", "14.99", "images/albums/gilberto-BIG.jpg", "images/albums/gilberto-BIG.jpg", "62");
        addRecord("Jazz", "Dave Brubeck", "Time Out", "1959", "19.99", "images/albums/brubeck-BIG.jpg", "images/albums/brubeck-BIG.jpg", "63");
        addRecord("Jazz", "The Quintet", "Jazz at Massey Hall", "1953", "24.99", "images/albums/quintet-BIG.jpg", "images/albums/quintet-BIG.jpg", "64");
        addRecord("Jazz", "Charles Mingus", "Mingus Ah Um", "1959", "14.99", "images/albums/mingus-BIG.jpg", "images/albums/mingus-BIG.jpg", "65");
        addRecord("Jazz", "John Coltrane", "Blue Train", "1957", "14.99", "images/albums/coltrane-BIG.jpg", "images/albums/coltrane-BIG.jpg", "66");
        addRecord("Jazz", "Cannonball Adderley", "Somethin\' Else", "1958", "14.99", "images/albums/cannonball-BIG.jpg", "images/albums/cannonball-BIG.jpg", "67");
        addRecord("Jazz", "Herbie Hancock", "Maiden Voyage", "1965", "14.99", "images/albums/hancock-BIG.jpg", "images/albums/hancock-BIG.jpg", "68");
        addRecord("Jazz", "Dexter Gordon", "Go!", "1962", "14.99", "images/albums/gordon-BIG.jpg", "images/albums/gordon-BIG.jpg", "69");
        addRecord("Jazz", "Sarah Vaughan", "Sarah Vaughan", "1955", "14.99", "images/albums/vaughan-BIG.jpg", "images/albums/vaughan-BIG.jpg", "70");


        // ======================================================================
        // Close connection with server
        // ======================================================================

        mysqli_close($conn);

    ?>

</body>

</html>
