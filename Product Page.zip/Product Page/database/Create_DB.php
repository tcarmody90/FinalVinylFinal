<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>Create DB</title>

      <style type="text/css">
         body {
            background-color: #83c985;
            font-family: Verdana, sans-serif;
            width: 100%;
            margin: auto;
            color: #ffffff
         }
         .center {
            display: block;
            position: relative;
            width:80%;
            margin:auto;
         }
         .ERR {
            color: red;
            font-weight: bold;
         }
      </style>

   </head>

   <body>

   <h2>Create Vinyls Database</h2>

      <div class="center">

      <?php

         // ======================================================================
         // Initialize MySQLi server connection parameters
         // ======================================================================

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "Vinyls";

         // ======================================================================
         // Create connection with server
         // ======================================================================

         $conn = mysqli_connect($servername, $username, $password);

         // ======================================================================
         // Check connection
         // ======================================================================

         if (!$conn)
         {
            die("Connection to server $servername failed: " . mysqli_connect_error() . "<br />");
         }
         else
         {
            echo "Connected to server $servername successfully<br />";
         }

         // ======================================================================
         // Create database: Vinyls
         // ======================================================================

         $sql = "CREATE DATABASE $dbName";

         if (mysqli_query($conn, $sql))
         {
             echo "Database $dbName created successfully";
         }
         else
         {
             echo "Error creating Database $dbName: " . mysqli_error($conn) . "<br />";
         }

         // ======================================================================
         // Close connection with server
         // ======================================================================

         mysqli_close($conn);

      ?>

      <h4> Return to <a href="DB_Menu.htm" >DB Menu</a> </h4>

      </div>

   </body>

</html>
