<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>Search Inventory Table</title>

      <style type="text/css">
         body {
            background-color: #83c985;
            font-family: Verdana, sans-serif;
            width: 100%;
            margin: auto;
            color: #ffffff;
         }
         table, tr, td {
            border-width: 3px;
            border-style: solid;
            border-color: #3e8e41;
            margin:auto;
         }
         .center {
            display: block;
            position: relative;
            width:80%;
            margin:auto;
         }
         .ERR {
            color: red;
            font-weight: bold;
         }
      </style>

   <?php
      function display_inventory($result, $nrows)
      {
         // ======================================================================
         // Display Selected Records
         // ======================================================================

         if ($nrows > 0)
         {
            // output header row
            echo "<table border='1'>";
            echo "<tr>";
            echo "<th>SKU #</th>";
            echo "<th>Genre</th>";
            echo "<th>Artist</th>";
            echo "<th>Title</th>";
            echo "<th>Year</th>";
            echo "<th>Price</th>";
            echo "<th>Album Cover</th>";
            echo "<th># In Stock</th>";
            echo "</tr>";

            // output data of each row
            while($row = mysqli_fetch_array($result))
            {
               echo "<tr>";
               echo "<td>" . $row["sku"] . "</td>";
               echo "<td>" . $row["genre"] . "</td>";
               echo "<td>" . $row["artist"] . "</td>";
               echo "<td>" . $row["title"] . "</td>";
               echo "<td>" . $row["year"] . "</td>";
               echo "<td>$" . $row["price"] . "</td>";
               echo "<td><img src='" . $row["album_cover_small"] . "' /></td>";
               echo "<td>" . $row["numberInStock"] . "</td>";
               echo "</tr>";
            }
            echo "</table>";
         }
         else
         {
            echo "0 results<br />";
         }
      }

   ?>

   </head>

   <body>

   <h2>Search Inventory Table</h2>

      <div class="center">

      <?php

         // ======================================================================
         // Initialize MySQLi server connection parameters
         // ======================================================================

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "Vinyls";
         $tableName = "Inventory";

         // ======================================================================
         // Create connection with server
         // ======================================================================

         $conn = new mysqli($servername, $username, $password, $dbName);

         // ======================================================================
         // Check connection
         // ======================================================================

         if (!$conn)
         {
            die("Connection to Database $dbName failed: " . mysqli_connect_error() . "<br />");
         }
         else
         {
            echo "Connected to Database $dbName successfully<br />";
         }

         // ======================================================================
         // Determine search key
         // ======================================================================

         $search_key = $_POST['search_key'];
         echo "<p> searching by " . $search_key . "</p>";

         switch ($search_key) {

            case "sku":

               // ======================================================================
               // Retrieve record by SKU
               // ======================================================================

               $sku_key = $_POST['sku'];

               echo "<p>searching for sku ". $sku_key . " in table " . $tableName . "</p>";
               echo "<p> query: SELECT * FROM " . $tableName . " WHERE sku=" . $sku_key . " </p>";
               $sql = "SELECT * FROM $tableName WHERE sku=$sku_key";
               break;

            case "genre":

               // ======================================================================
               // Retrieve record by genre
               // ======================================================================

               $genre_key = $_POST['genre'];

               echo "<p>searching for genre ". $genre_key . " in table " . $tableName . "</p>";
               echo "<p> query: SELECT * FROM " . $tableName . " WHERE genre='" . $genre_key . "' </p>";
               $sql = "SELECT * FROM $tableName WHERE genre='$genre_key'";
               break;

            case "artist":

               // ======================================================================
               // Retrieve record by artist
               // ======================================================================

               $artist_key = $_POST['artist'];

               echo "<p>searching for artist ". $artist_key . " in table " . $tableName . "</p>";
               echo "<p> query: SELECT * FROM " . $tableName . " WHERE artist LIKE '%" . $artist_key . "%' </p>";
               $sql = "SELECT * FROM $tableName WHERE artist LIKE '%$artist_key%'";
               break;

            case "title":

               // ======================================================================
               // Retrieve record by title
               // ======================================================================

               $title_key = $_POST['title'];

               echo "<p>searching for title ". $title_key . " in table " . $tableName . "</p>";
               echo "<p> query: SELECT * FROM " . $tableName . " WHERE title LIKE '%" . $title_key . "%' </p>";
               $sql = "SELECT * FROM $tableName WHERE title LIKE '%$title_key%'";
               break;

            case "year":

               // ======================================================================
               // Retrieve record by year
               // ======================================================================

               $year_key = $_POST['year'];

               echo "<p>searching for year ". $year_key . " in table " . $tableName . "</p>";
               echo "<p> query: SELECT * FROM " . $tableName . " WHERE year=" . $year_key . " </p>";
               $sql = "SELECT * FROM $tableName WHERE year=$year_key";
               break;
         }

         $result = mysqli_query($conn, $sql);
         $nrows = mysqli_num_rows($result);
         echo "<p> number of rows retrieved: " . $nrows . "</p>";

         // ======================================================================
         // Display Selected Records
         // ======================================================================

         display_inventory($result, $nrows);

         // ======================================================================
         // Close connection with server
         // ======================================================================

         mysqli_close($conn);

      ?>

      <form action="Display_Table_Inventory.php">
         <h4>
            Display Inventory&nbsp;
            <button>Display Inventory Table</button>
         </h4>
      </form>

      <h4> Add A Record <a href="Add_To_Table_Inventory.htm" ><button>Add Record To Inventory Table</button></a> </h4>

      <form action="Delete_From_Table_Inventory.php" method="post">
         <h4>
            Delete A Record (SKU#): &nbsp;&nbsp;
            <input type="text" name="sku" id="sku" />
            &nbsp;&nbsp;
            <input type="submit" value="Delete Record From Inventory Table" />
         </h4>
      </form>

      <form action="Edit_Table_Inventory.php" method="post">
         <h4>
            Edit A Record (SKU#): &nbsp;&nbsp;
            <input type="text" name="sku" id="sku" />
            &nbsp;&nbsp;
            <input type="submit" value="Edit Record From Inventory Table" />
         </h4>
      </form>

      <h4> Do Another Search <a href="Search_Table_Inventory.htm"><button>Search Inventory Table</button></a> </h4>

      <h4> Return to Main Menu <a href="DB_Menu.htm" ><button>DB Menu</button></a> </h4>

      </div>

   </body>

</html>
