<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>Create Inventory Table</title>

      <style type="text/css">
         body {
            background-color: #83c985;
            font-family: Verdana, sans-serif;
            width: 100%;
            margin: auto;
            color: #ffffff
         }
         .center {
            display: block;
            position: relative;
            width:80%;
            margin:auto;
         }
         .ERR {
            color: red;
            font-weight: bold;
         }
      </style>

   </head>

   <body>

   <h2>Create Inventory Table</h2>

      <div class="center">

      <?php

         // ======================================================================
         // Initialize MySQLi server connection parameters
         // ======================================================================

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "Vinyls";
         $tableName = "Inventory";

         // ======================================================================
         // Create connection with server
         // ======================================================================

         $conn = new mysqli($servername, $username, $password, $dbName);

         // ======================================================================
         // Check connection
         // ======================================================================

         if (!$conn)
         {
            die("Connection to Database $dbName failed: " . mysqli_connect_error() . "<br />");
         }
         else
         {
            echo "Connected to Database $dbName successfully<br /><br />";
         }

         // ======================================================================
         // Create table: Inventory
         // ======================================================================

         $sql = "CREATE TABLE Inventory
         (
            sku SMALLINT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            genre VARCHAR(255) NOT NULL,
            artist VARCHAR(255) NOT NULL,
            title VARCHAR(255) NOT NULL,
            year SMALLINT(4) UNSIGNED,
            price FLOAT(7,2) NOT NULL,
            album_cover_big VARCHAR(255),
            album_cover_small VARCHAR(255),
            numberInStock SMALLINT(4) UNSIGNED NOT NULL
         )";

         if (mysqli_query($conn, $sql))
         {
            echo "Table $tableName created successfully<br />";
         }
         else
         {
            echo "Error creating Table $tableName: " . mysqli_error($conn) . "<br />";
         }

         // ======================================================================
         // Close connection with server
         // ======================================================================

         mysqli_close($conn);

      ?>

      <h4> Return to <a href="DB_Menu.htm" >DB Menu</a> </h4>

      </div>

   </body>

</html>
