$(document).ready(function(){
  $('a[href^="#"]').on('click',function (e) {
      e.preventDefault();

      var target = this.hash;
      var $target = $(target);

      $('html, body').stop().animate({
          'scrollTop': $target.offset().top
      }, 900, 'swing', function () {
          window.location.hash = target;
      });
  });
});

function init() {
    window.addEventListener('scroll', function(e){
        var distanceY = window.pageYOffset || document.documentElement.scrollTop,
            shrinkOn = 100,
            header = document.querySelector("header");
        if (distanceY > shrinkOn) {
            // classie.add(header,".logochange");
            document.querySelector("#nav-home").innerHTML = "<img class=\"logochange\" src=\"pics/logo8.png\" style='margin-top: -15px; width: 300px !important;' />";
        } else {
            // if (classie.has(header,".logochange")) {
                // classie.remove(header,".logochange");
            document.querySelector("#nav-home").innerHTML = "<img src=\"pics/log6.png\">";
            // }
        }
    });

    $(".homePresent .dontDisplay").css("margin-top", $(this).position.top+50);
    $(".homePresent .dontDisplay").delay(500).animate({'margin-top': "-50", opacity: "show"}, "slow");
}
window.onload = init();
/********

I FOUND THIS TUTORIAL AT:
https://paulund.co.uk/smooth-scroll-to-internal-links-with-jquery 

jQuery animate function

********/
